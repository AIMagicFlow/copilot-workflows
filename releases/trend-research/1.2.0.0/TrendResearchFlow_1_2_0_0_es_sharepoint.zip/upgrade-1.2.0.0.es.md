# Notas de actualización de la versión 1.2.0.0

Esta versión agrega las listas y columnas siguientes. Si aprovisionó con PnP, vuelva a ejecutar pnp/provision.ps1 de este kit y no necesita nada más. Si creó las listas desde los archivos CSV, agréguelas a mano como se describe aquí.

**Al crear cada columna, escriba primero el nombre interno, guárdela y solo después cambie el nombre al nombre para mostrar. SharePoint fija el nombre interno con el primer nombre que se escribe.**

Bibliotecas nuevas (cree cada una a mano con este nombre de URL y luego agregue las carpetas):

- Cargas de fuentes (`SourceUploads`): carpetas PublicData

| Lista | Nombre interno | Tipo | Opciones | Nombre para mostrar |
| --- | --- | --- | --- | --- |
| Fuentes | `SourcePath` | Text |  | Ruta de la fuente |
