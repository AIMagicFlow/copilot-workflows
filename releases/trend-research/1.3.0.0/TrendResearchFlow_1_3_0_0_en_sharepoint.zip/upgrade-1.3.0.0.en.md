# Upgrade notes for version 1.3.0.0

This release adds the lists and columns below. If you provisioned with PnP, re-run pnp/provision.ps1 from this kit and nothing else is needed. If you created the lists from the CSV files, add them by hand as described here.

**Type the internal name first when you create each column, save it, and only then rename the column to the display name. SharePoint fixes the internal name from the first name you type.**

New lists (create each one from its CSV file in lists/):

- BusinessCaseRequests

| List | Internal name | Type | Choices | Display name |
| --- | --- | --- | --- | --- |
| ResearchBriefs | `Product` | Text |  | Product |
| ResearchBriefs | `Dimension` | Choice | Market, Technology, Regulatory, Competition | Dimension |
| ResearchBriefs | `BriefType` | Choice | Monitoring, Investigation | BriefType |
| Signals | `AlertTags` | MultiChoice | CompetitorLaunch, RegulatoryAlert, NewTechnology | AlertTags |
| Signals | `Objectives` | MultiChoice | Anticipate, MinimizeRisks, Compare, Innovate, Cooperate | Objectives |
| Publications | `BriefId` | Number |  | BriefId |
| Publications | `Product` | Text |  | Product |
| Publications | `Dimension` | Text |  | Dimension |
| Publications | `PublicationType` | Choice | Digest, BusinessCase | PublicationType |
| Publications | `BusinessCaseRequestId` | Number |  | BusinessCaseRequestId |
| Publications | `InputPublicationIds` | Text |  | InputPublicationIds |
| Publications | `ReviewStatus` | Choice | Draft, InReview, Approved, Rejected | ReviewStatus |
| Publications | `Version` | Number |  | Version |
| BusinessCaseRequests | `Product` | Text |  | Product |
| BusinessCaseRequests | `DecisionQuestion` | Note |  | DecisionQuestion |
| BusinessCaseRequests | `Geographies` | Text |  | Geographies |
| BusinessCaseRequests | `TimeHorizon` | Text |  | TimeHorizon |
| BusinessCaseRequests | `Alternatives` | Note |  | Alternatives |
| BusinessCaseRequests | `StrategicObjectives` | Note |  | StrategicObjectives |
| BusinessCaseRequests | `FinancialInputs` | Note |  | FinancialInputs |
| BusinessCaseRequests | `Constraints` | Note |  | Constraints |
| BusinessCaseRequests | `InputPublicationIds` | Text |  | InputPublicationIds |
| BusinessCaseRequests | `ReviewerEmail` | Text |  | ReviewerEmail |
| BusinessCaseRequests | `AudienceKey` | Text |  | AudienceKey |
| BusinessCaseRequests | `PreviousRequestId` | Number |  | PreviousRequestId |
| BusinessCaseRequests | `Version` | Number |  | Version |
| BusinessCaseRequests | `Status` | Choice | Draft, Submitted, Generating, InReview, Approved, Rejected, Failed | Status |
| BusinessCaseRequests | `PublicationId` | Number |  | PublicationId |
| BusinessCaseRequests | `LastError` | Note |  | LastError |
