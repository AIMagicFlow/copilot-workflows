# Notas de actualización de la versión 1.3.0.0

Esta versión agrega las listas y columnas siguientes. Si aprovisionó con PnP, vuelva a ejecutar pnp/provision.ps1 de este kit y no necesita nada más. Si creó las listas desde los archivos CSV, agréguelas a mano como se describe aquí.

**Al crear cada columna, escriba primero el nombre interno, guárdela y solo después cambie el nombre al nombre para mostrar. SharePoint fija el nombre interno con el primer nombre que se escribe.**

Listas nuevas (cree cada una desde su archivo CSV en lists/):

- SolicitudesCasoNegocio

| Lista | Nombre interno | Tipo | Opciones | Nombre para mostrar |
| --- | --- | --- | --- | --- |
| Briefs | `Product` | Text |  | Producto |
| Briefs | `Dimension` | Choice | Market, Technology, Regulatory, Competition | Dimensión |
| Briefs | `BriefType` | Choice | Monitoring, Investigation | Tipo de brief |
| Señales | `AlertTags` | MultiChoice | CompetitorLaunch, RegulatoryAlert, NewTechnology | Etiquetas de alerta |
| Señales | `Objectives` | MultiChoice | Anticipate, MinimizeRisks, Compare, Innovate, Cooperate | Objetivos estratégicos |
| Publicaciones | `BriefId` | Number |  | ID del brief |
| Publicaciones | `Product` | Text |  | Producto |
| Publicaciones | `Dimension` | Text |  | Dimensión |
| Publicaciones | `PublicationType` | Choice | Digest, BusinessCase | Tipo de publicación |
| Publicaciones | `BusinessCaseRequestId` | Number |  | ID de solicitud de caso de negocio |
| Publicaciones | `InputPublicationIds` | Text |  | IDs de publicaciones de entrada |
| Publicaciones | `ReviewStatus` | Choice | Draft, InReview, Approved, Rejected | Estado de revisión |
| Publicaciones | `Version` | Number |  | Versión |
| SolicitudesCasoNegocio | `Product` | Text |  | Producto |
| SolicitudesCasoNegocio | `DecisionQuestion` | Note |  | Pregunta de decisión |
| SolicitudesCasoNegocio | `Geographies` | Text |  | Geografías |
| SolicitudesCasoNegocio | `TimeHorizon` | Text |  | Horizonte temporal |
| SolicitudesCasoNegocio | `Alternatives` | Note |  | Alternativas |
| SolicitudesCasoNegocio | `StrategicObjectives` | Note |  | Objetivos estratégicos |
| SolicitudesCasoNegocio | `FinancialInputs` | Note |  | Datos financieros |
| SolicitudesCasoNegocio | `Constraints` | Note |  | Restricciones |
| SolicitudesCasoNegocio | `InputPublicationIds` | Text |  | IDs de publicaciones de entrada |
| SolicitudesCasoNegocio | `ReviewerEmail` | Text |  | Correo del revisor |
| SolicitudesCasoNegocio | `AudienceKey` | Text |  | Clave de audiencia |
| SolicitudesCasoNegocio | `PreviousRequestId` | Number |  | ID de solicitud previa |
| SolicitudesCasoNegocio | `Version` | Number |  | Versión |
| SolicitudesCasoNegocio | `Status` | Choice | Draft, Submitted, Generating, InReview, Approved, Rejected, Failed | Estado |
| SolicitudesCasoNegocio | `PublicationId` | Number |  | ID de publicación |
| SolicitudesCasoNegocio | `LastError` | Note |  | Último error |
