# Upgrade notes for version 1.2.0.0

This release adds the lists and columns below. If you provisioned with PnP, re-run pnp/provision.ps1 from this kit and nothing else is needed. If you created the lists from the CSV files, add them by hand as described here.

**Type the internal name first when you create each column, save it, and only then rename the column to the display name. SharePoint fixes the internal name from the first name you type.**

New libraries (create each one by hand with this URL name, then add the folders):

- Source Uploads (`SourceUploads`): folders PublicData

| List | Internal name | Type | Choices | Display name |
| --- | --- | --- | --- | --- |
| Sources | `SourcePath` | Text |  | SourcePath |
