﻿<#
.SYNOPSIS
    Creates or updates the SharePoint lists and libraries of this solution, then verifies every column.

.DESCRIPTION
    Applies sharepoint-template.pnp.xml with PnP PowerShell. The template fixes each column internal name, so the flows work in any tenant. Safe to run again, for example after an upgrade, because existing lists, columns and rows are kept. With -VerifyOnly it only checks an existing site, for example one whose lists were created from the CSV files.

.PARAMETER SiteUrl
    Full URL of the SharePoint site, for example https://contoso.sharepoint.com/sites/TrendResearch

.PARAMETER ClientId
    Application (client) ID of the Entra ID app registered for PnP PowerShell.

.PARAMETER VerifyOnly
    Only check the site, change nothing.

.EXAMPLE
    ./provision.ps1 -SiteUrl https://contoso.sharepoint.com/sites/TrendResearch -ClientId 00000000-0000-0000-0000-000000000000

.EXAMPLE
    ./provision.ps1 -SiteUrl https://contoso.sharepoint.com/sites/TrendResearch -ClientId 00000000-0000-0000-0000-000000000000 -VerifyOnly
#>
#Requires -Version 7.4

param(
    [Parameter(Mandatory)] [string] $SiteUrl,
    [Parameter(Mandatory)] [string] $ClientId,
    [switch] $VerifyOnly
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
    throw 'PnP.PowerShell is not installed. Run - Install-Module PnP.PowerShell -Scope CurrentUser'
}

$template = Join-Path $PSScriptRoot 'sharepoint-template.pnp.xml'
$expected = Get-Content (Join-Path $PSScriptRoot 'expected-schema.json') -Raw -Encoding utf8 | ConvertFrom-Json

Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Interactive

if (-not $VerifyOnly) {
    Write-Host 'Applying the SharePoint template...'
    Invoke-PnPSiteTemplate -Path $template
}

Write-Host 'Verifying lists, libraries and columns...'
$problems = [System.Collections.Generic.List[string]]::new()

foreach ($library in $expected.libraries) {
    if (-not (Get-PnPList -Identity $library.url -ErrorAction SilentlyContinue)) {
        $problems.Add("$($library.title) [$($library.url)]: library not found")
    }
}

foreach ($list in $expected.lists) {
    # Lists created by the template live at Lists/<EnglishName>; lists created from CSV
    # live at a URL derived from their title. Find either one by title first.
    $spList = Get-PnPList -Identity $list.title -ErrorAction SilentlyContinue
    if (-not $spList) { $spList = Get-PnPList -Identity $list.url -ErrorAction SilentlyContinue }
    if (-not $spList) {
        $problems.Add("$($list.title): list not found")
        continue
    }
    $fields = Get-PnPField -List $spList
    foreach ($field in $list.fields) {
        $actual = $fields | Where-Object { $_.InternalName -ceq $field.name } | Select-Object -First 1
        $label = "$($list.title) / $($field.display) [$($field.name)]"
        if (-not $actual) {
            $sameTitle = $fields | Where-Object { $_.Title -eq $field.display } | Select-Object -First 1
            $hint = if ($sameTitle) { " (a column with this name exists with internal name $($sameTitle.InternalName))" } else { '' }
            $problems.Add("${label}: column not found$hint")
            continue
        }
        if ($actual.TypeAsString -ne $field.type) {
            $problems.Add("${label}: wrong column type $($actual.TypeAsString) -> $($field.type)")
        }
        if ($field.unique -and -not $actual.EnforceUniqueValues) {
            $problems.Add("${label}: must enforce unique values")
        }
    }
}

if ($problems.Count -gt 0) {
    $problems | ForEach-Object { Write-Host "  x $_" -ForegroundColor Red }
    Write-Host 'The site does not match the expected schema. Fix the items above before importing or running the solution.' -ForegroundColor Red
    exit 1
}
Write-Host 'All lists, libraries and columns match the expected schema.' -ForegroundColor Green
