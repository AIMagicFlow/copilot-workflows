﻿<#
.SYNOPSIS
    Crea o actualiza las listas y bibliotecas de SharePoint de esta solución y verifica cada columna.

.DESCRIPTION
    Aplica sharepoint-template.pnp.xml con PnP PowerShell. La plantilla fija el nombre interno de cada columna, así los flujos funcionan en cualquier tenant. Se puede ejecutar de nuevo, por ejemplo después de una actualización, porque conserva las listas, columnas y filas existentes. Con -VerifyOnly solo revisa un sitio existente, por ejemplo uno cuyas listas se crearon desde los archivos CSV.

.PARAMETER SiteUrl
    URL completa del sitio de SharePoint, por ejemplo https://contoso.sharepoint.com/sites/VigilanteTendencias

.PARAMETER ClientId
    ID de aplicación (cliente) de la app de Entra ID registrada para PnP PowerShell.

.PARAMETER VerifyOnly
    Solo revisa el sitio, no cambia nada.

.EXAMPLE
    ./provision.ps1 -SiteUrl https://contoso.sharepoint.com/sites/TrendResearch -ClientId 00000000-0000-0000-0000-000000000000

.EXAMPLE
    ./provision.ps1 -SiteUrl https://contoso.sharepoint.com/sites/TrendResearch -ClientId 00000000-0000-0000-0000-000000000000 -VerifyOnly
#>
#Requires -Version 7.4

param(
    [Parameter(Mandatory)] [string] $SiteUrl,
    [Parameter(Mandatory)] [string] $ClientId,
    [switch] $VerifyOnly
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
    throw 'PnP.PowerShell no está instalado. Ejecute - Install-Module PnP.PowerShell -Scope CurrentUser'
}

$template = Join-Path $PSScriptRoot 'sharepoint-template.pnp.xml'
$expected = Get-Content (Join-Path $PSScriptRoot 'expected-schema.json') -Raw -Encoding utf8 | ConvertFrom-Json

Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Interactive

if (-not $VerifyOnly) {
    Write-Host 'Aplicando la plantilla de SharePoint...'
    Invoke-PnPSiteTemplate -Path $template
}

Write-Host 'Verificando listas, bibliotecas y columnas...'
$problems = [System.Collections.Generic.List[string]]::new()

foreach ($library in $expected.libraries) {
    if (-not (Get-PnPList -Identity $library.url -ErrorAction SilentlyContinue)) {
        $problems.Add("$($library.title) [$($library.url)]: no se encontró la biblioteca")
    }
}

foreach ($list in $expected.lists) {
    # Lists created by the template live at Lists/<EnglishName>; lists created from CSV
    # live at a URL derived from their title. Find either one by title first.
    $spList = Get-PnPList -Identity $list.title -ErrorAction SilentlyContinue
    if (-not $spList) { $spList = Get-PnPList -Identity $list.url -ErrorAction SilentlyContinue }
    if (-not $spList) {
        $problems.Add("$($list.title): no se encontró la lista")
        continue
    }
    $fields = Get-PnPField -List $spList
    foreach ($field in $list.fields) {
        $actual = $fields | Where-Object { $_.InternalName -ceq $field.name } | Select-Object -First 1
        $label = "$($list.title) / $($field.display) [$($field.name)]"
        if (-not $actual) {
            $sameTitle = $fields | Where-Object { $_.Title -eq $field.display } | Select-Object -First 1
            $hint = if ($sameTitle) { " (existe una columna con este nombre pero su nombre interno es $($sameTitle.InternalName))" } else { '' }
            $problems.Add("${label}: no se encontró la columna$hint")
            continue
        }
        if ($actual.TypeAsString -ne $field.type) {
            $problems.Add("${label}: tipo de columna incorrecto $($actual.TypeAsString) -> $($field.type)")
        }
        if ($field.unique -and -not $actual.EnforceUniqueValues) {
            $problems.Add("${label}: debe exigir valores únicos")
        }
    }
}

if ($problems.Count -gt 0) {
    $problems | ForEach-Object { Write-Host "  x $_" -ForegroundColor Red }
    Write-Host 'El sitio no coincide con el esquema esperado. Corrija los puntos anteriores antes de importar o ejecutar la solución.' -ForegroundColor Red
    exit 1
}
Write-Host 'Todas las listas, bibliotecas y columnas coinciden con el esquema esperado.' -ForegroundColor Green
